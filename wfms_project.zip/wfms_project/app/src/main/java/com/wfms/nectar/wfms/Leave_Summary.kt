package com.wfms.nectar.wfms

import android.os.Build
import android.os.Bundle
import android.support.annotation.RequiresApi
import android.support.v7.app.AppCompatActivity
import android.view.WindowManager
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.utils.ColorTemplate
import android.R.attr.entries
import com.github.mikephil.charting.data.BarEntry
import android.R.attr.entries
import kotlinx.android.synthetic.main.leave_summary_layout.*
import android.R.attr.entries


class Leave_Summary  : AppCompatActivity() {
    var entries: ArrayList<Entry>? = null
    var PieEntryLabels: ArrayList<String>? = null
    var pieDataSet: PieDataSet? = null
    var pieData: PieData? = null
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN)
        setContentView(R.layout.leave_summary_layout)
        piechart()

}

    private fun piechart() {
        entries = ArrayList<Entry>()

        PieEntryLabels = ArrayList()

        AddValuesToPIEENTRY()

        AddValuesToPieEntryLabels()

        pieDataSet = PieDataSet(entries, "")

        pieData = PieData(PieEntryLabels, pieDataSet)

        pieDataSet!!.setColors(ColorTemplate.COLORFUL_COLORS)

        pieChart.setData(pieData)

        pieChart.animateY(3000)
    }

    fun AddValuesToPIEENTRY() {
        entries?.add(BarEntry(2f, 0))
        entries?.add(BarEntry(4f, 1))
        entries?.add(BarEntry(6f, 2))
        entries?.add(BarEntry(8f, 3))

    }
    fun AddValuesToPieEntryLabels() {
        PieEntryLabels?.add("Total Balance")
        PieEntryLabels?.add("Pending Leaves")
        PieEntryLabels?.add("Approve Leaves")
        PieEntryLabels?.add("Rejected Leaves")
    }
}
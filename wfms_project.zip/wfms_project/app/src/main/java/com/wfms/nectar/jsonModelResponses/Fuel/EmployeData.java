
package com.wfms.nectar.jsonModelResponses.Fuel;

import android.os.Parcel;
import android.os.Parcelable;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class EmployeData implements Parcelable
{
    private String islogin;
    private String isupload;
    private String password;
    private String latitude;
    private String longtitude;
    private String Image;

    public String getIslogin() {
        return islogin;
    }

    public void setIslogin(String islogin) {
        this.islogin = islogin;
    }

    public String getIsupload() {
        return isupload;
    }

    public void setIsupload(String isupload) {
        this.isupload = isupload;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getImage() {
        return Image;
    }

    public void setImage(String image) {
        Image = image;
    }

    public String getLatitude() {
        return latitude;
    }

    public void setLatitude(String latitude) {
        this.latitude = latitude;
    }

    public String getLongtitude() {
        return longtitude;
    }

    public void setLongtitude(String longtitude) {
        this.longtitude = longtitude;
    }

    @SerializedName("user_id")
    @Expose

    private String user_id;
    @SerializedName("username")
    @Expose

    private String username1;
    @SerializedName("attendance_id")
    @Expose
    private String attendance_id;
    @SerializedName("name")
    @Expose
    private String username;
    @SerializedName("in_date")
    @Expose
    private String in_date;
    @SerializedName("in_time")
    @Expose
    private String in_time;
    @SerializedName("out_date")
    @Expose
    private String out_date;
    @SerializedName("out_time")
    @Expose
    private String out_time;

    public String getIn_location_url() {
        return in_location_url;
    }

    public void setIn_location_url(String in_location_url) {
        this.in_location_url = in_location_url;
    }

    public String getOut_location_url() {
        return out_location_url;
    }

    public void setOut_location_url(String out_location_url) {
        this.out_location_url = out_location_url;
    }

    @SerializedName("in_location")
    @Expose
    private String in_location;
    @SerializedName("in_location_url")
    @Expose
    private String in_location_url;
    @SerializedName("out_location_url")
    @Expose
    private String out_location_url;

    public String getIn_mac_address() {
        return in_mac_address;
    }

    public void setIn_mac_address(String in_mac_address) {
        this.in_mac_address = in_mac_address;
    }

    public String getOut_mac_address() {
        return out_mac_address;
    }

    public void setOut_mac_address(String out_mac_address) {
        this.out_mac_address = out_mac_address;
    }

    @SerializedName("in_mac_address")

    @Expose
    private String in_mac_address;
    @SerializedName("out_mac_address")
    @Expose
    private String out_mac_address;
    public String getTime_duration() {
        return time_duration;
    }

    public void setTime_duration(String time_duration) {
        this.time_duration = time_duration;
    }

    @SerializedName("out_location")
    @Expose

    private String out_location;
    @SerializedName("time_duration")
    @Expose
    private String time_duration;
    private String company;

    public String getIn_location() {
        return in_location;
    }

    public void setIn_location(String in_location) {
        this.in_location = in_location;
    }

    public String getOut_location() {
        return out_location;
    }

    public void setOut_location(String out_location) {
        this.out_location = out_location;
    }

    public EmployeData() {

    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getVehicle_type_image() {
        return vehicle_type_image;
    }

    public void setVehicle_type_image(String vehicle_type_image) {
        this.vehicle_type_image = vehicle_type_image;
    }

    @SerializedName("vehicle_type_image")
    @Expose
    private String vehicle_type_image;

    public final static Creator<EmployeData> CREATOR = new Creator<EmployeData>() {


        @SuppressWarnings({
            "unchecked"
        })
        public EmployeData createFromParcel(Parcel in) {
            return new EmployeData(in);
        }

        public EmployeData[] newArray(int size) {
            return (new EmployeData[size]);
        }

    }
    ;

    public EmployeData(Parcel in) {
        this.user_id = ((String) in.readValue((String.class.getClassLoader())));
        this.attendance_id = ((String) in.readValue((String.class.getClassLoader())));
        this.username = ((String) in.readValue((String.class.getClassLoader())));
        this.in_date = ((String) in.readValue((String.class.getClassLoader())));
        this.in_time = ((String) in.readValue((String.class.getClassLoader())));
        this.out_date = ((String) in.readValue((String.class.getClassLoader())));
        this.in_location = ((String) in.readValue((String.class.getClassLoader())));
        this.out_location = ((String) in.readValue((String.class.getClassLoader())));
        this.out_time = ((String) in.readValue((String.class.getClassLoader())));
        this.time_duration = ((String) in.readValue((String.class.getClassLoader())));
        this.in_location_url = ((String) in.readValue((String.class.getClassLoader())));
        this.out_location_url = ((String) in.readValue((String.class.getClassLoader())));
        this.in_mac_address = ((String) in.readValue((String.class.getClassLoader())));
        this.out_mac_address = ((String) in.readValue((String.class.getClassLoader())));
        this.username1 = ((String) in.readValue((String.class.getClassLoader())));


    }

    public String getUsername1() {
        return username1;
    }

    public void setUsername1(String username1) {
        this.username1 = username1;
    }

    public String getUser_id() {
        return user_id;
    }

    public void setUser_id(String user_id) {
        this.user_id = user_id;
    }

    public String getAttendance_id() {
        return attendance_id;
    }

    public void setAttendance_id(String attendance_id) {
        this.attendance_id = attendance_id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getIn_date() {
        return in_date;
    }

    public void setIn_date(String in_date) {
        this.in_date = in_date;
    }

    public String getIn_time() {
        return in_time;
    }

    public void setIn_time(String in_time) {
        this.in_time = in_time;
    }

    public String getOut_date() {
        return out_date;
    }

    public void setOut_date(String out_date) {
        this.out_date = out_date;
    }

    public String getOut_time() {
        return out_time;
    }

    public void setOut_time(String out_time) {
        this.out_time = out_time;
    }


    public void writeToParcel(Parcel dest, int flags) {
        dest.writeValue(user_id);
        dest.writeValue(username);
        dest.writeValue(in_date);
        dest.writeValue(in_time);
        dest.writeValue(out_date);
        dest.writeValue(out_time);
        dest.writeValue(in_location);
        dest.writeValue(out_location);
        dest.writeValue(time_duration);
        dest.writeValue(in_location_url);
        dest.writeValue(out_location_url);
        dest.writeValue(in_mac_address);
        dest.writeValue(out_mac_address);
        dest.writeValue(username1);
    }

    public int describeContents() {
        return  0;
    }

}

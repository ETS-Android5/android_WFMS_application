package com.wfms.nectar.wfms

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.support.design.widget.TabLayout
import android.support.v7.app.AppCompatActivity
import android.view.WindowManager
import butterknife.OnClick
import com.wfms.nectar.Adapter.Leave_Adapter
import kotlinx.android.synthetic.main.leave_layout.*
import kotlinx.android.synthetic.main.leave_request_layout.*
import java.util.*

class Leave_Activity:AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN)
        setContentView(R.layout.leave_layout)
       //tabLayout!!.addTab(tabLayout!!.newTab().setText("Available Leaves"))
        tabLayout!!.addTab(tabLayout!!.newTab().setText("Pending Leaves"))
        tabLayout!!.addTab(tabLayout!!.newTab().setText("Approve Leaves"))
        tabLayout!!.addTab(tabLayout!!.newTab().setText("Rejected Leaves"))

        tabLayout!!.tabGravity = TabLayout.GRAVITY_FILL

        val adapter = Leave_Adapter(this, supportFragmentManager, tabLayout!!.tabCount)
        viewPager!!.adapter = adapter

        viewPager!!.addOnPageChangeListener(TabLayout.TabLayoutOnPageChangeListener(tabLayout))

        tabLayout!!.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) {
                viewPager!!.currentItem = tab.position
            }
            override fun onTabUnselected(tab: TabLayout.Tab) {

            }
            override fun onTabReselected(tab: TabLayout.Tab) {

            }
        })
        fab.setOnClickListener { view ->
            intent = Intent(applicationContext, Leave_Request_Activity::class.java)
            startActivity(intent)
        }
        back_layout1.setOnClickListener { view ->
            finish()
        }
    }

}
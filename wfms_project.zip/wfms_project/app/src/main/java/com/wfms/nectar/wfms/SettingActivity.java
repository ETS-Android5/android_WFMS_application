package com.wfms.nectar.wfms;

import android.content.Intent;
import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.CompoundButton;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.ToggleButton;

import com.suke.widget.SwitchButton;
import com.wfms.nectar.jsonModelResponses.signup.SignUpResponse;
import com.wfms.nectar.presenter.presenterImpl.SignUpPresenterImpl;
import com.wfms.nectar.utils.AppConstants;
import com.wfms.nectar.utils.PrefUtils;
import com.wfms.nectar.viewstate.SignUpView;

/**
 * Created by Nectar on 17-06-2019.
 */

public class SettingActivity extends AppCompatActivity implements SignUpView {
    SwitchButton notification_enable;
    String isnotication;
    TextView notification_text;
    RelativeLayout back;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setContentView(R.layout.setting_layout);
        notification_enable=(SwitchButton)findViewById(R.id.notification_enable);
        notification_text=(TextView)findViewById(R.id.notification_text);
        notification_enable.setShadowEffect(true);
        notification_enable.setEnableEffect(true);
        back = (RelativeLayout) findViewById(R.id.back_layout);

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(PrefUtils.getKey(SettingActivity.this, AppConstants.UserID).equalsIgnoreCase("1"))
                {
                    finish();
                }
                else
                {
                    Intent i = new Intent(SettingActivity.this, MainActivity.class);
                    startActivity(i);
                    finish();
                }
            }
        });
        if(PrefUtils.getKey(SettingActivity.this,AppConstants.Isnotification)!=null)
        {
            if(PrefUtils.getKey(SettingActivity.this,AppConstants.Isnotification).equals("1"))
            {
                notification_text.setText("On");
                notification_enable.setChecked(true);
            }else
            {
                notification_text.setText("Off");
                notification_enable.setChecked(false);
            }
        }else
        {
            notification_text.setText("On");
            notification_enable.setChecked(true);
        }
        notification_enable.setOnCheckedChangeListener(new SwitchButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(SwitchButton view, boolean isChecked) {
                //TODO do your job
                if(notification_enable.isChecked())
                {
                    initnotificationenableAPIResources(PrefUtils.getKey(SettingActivity.this,AppConstants.UserID),PrefUtils.getKey(SettingActivity.this,AppConstants.Clientid), "1");
                    isnotication="1";
                }
                else
                {
                    initnotificationenableAPIResources(PrefUtils.getKey(SettingActivity.this,AppConstants.UserID),PrefUtils.getKey(SettingActivity.this,AppConstants.Clientid), "0");
                    isnotication="0";
                }
            }
        });


    }

    private void initnotificationenableAPIResources(String userid, String clientid, String isnotification) {
        SignUpPresenterImpl notificationPresenter = new SignUpPresenterImpl(SettingActivity.this);
        notificationPresenter.callApi(AppConstants.NotificationEnable, userid, clientid,isnotification);

}

    @Override
    public void onSignUpSuccess(SignUpResponse signUpResponse) {
        if(isnotication.equals("1"))
        {
            notification_text.setText("On");
            notification_enable.setChecked(true);
        }
        else
        {
            notification_text.setText("Off");
            notification_enable.setChecked(false);
        }
        PrefUtils.storeKey(SettingActivity.this,AppConstants.Isnotification,isnotication);
    }

    @Override
    public void onSignUpFailure(String msg) {

    }
}


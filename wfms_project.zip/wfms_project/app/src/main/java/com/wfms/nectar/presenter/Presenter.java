package com.wfms.nectar.presenter;

/**
 * Created by aashita on 27-Jul-17.
 */

public interface Presenter {
    void callApi(Object... args);
}

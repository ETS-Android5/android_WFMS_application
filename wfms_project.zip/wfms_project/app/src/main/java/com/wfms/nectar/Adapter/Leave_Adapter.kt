package com.wfms.nectar.Adapter

import android.support.v4.app.FragmentPagerAdapter
import android.content.Context;

import android.support.v4.app.Fragment
import android.support.v4.app.FragmentManager
import com.wfms.nectar.wfms.ApproveLeaves_Fragment
import com.wfms.nectar.wfms.PendingLeaves_Fragment
import com.wfms.nectar.wfms.RejectedLeaves_Fragment


class Leave_Adapter(private val myContext: Context, fm: FragmentManager, internal var totalTabs: Int) : FragmentPagerAdapter(fm) {

    // this is for fragment tabs
    override fun getItem(position: Int): Fragment? {
        when (position) {
            0 -> {
                return PendingLeaves_Fragment()
            }
            1 -> {
                return ApproveLeaves_Fragment()
            }
            2 -> {
                return RejectedLeaves_Fragment()
            }
            else -> return null
        }
    }
    // this counts total number of tabs
    override fun getCount(): Int {
        return totalTabs
    }
}
package com.wfms.nectar.retrofit;

import com.google.gson.JsonObject;
import com.wfms.nectar.utils.AppConstants;
import com.wfms.nectar.wfms.SplashActivity;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;

/**
 * Created by abhishek on 25/07/17.
 */

public interface RetroAPIInterface {
    String BASE_URL = SplashActivity.validurl;


    /**
     * User Login and Registration
     */
    @FormUrlEncoded
    @POST( AppConstants.BASE_URL+"login")
    Call<JsonObject> callLoginAPI(@Field("username") String username, @Field("password") String password,@Field("tokenid") String tokenid,@Field("clientname") String clientname);

    @FormUrlEncoded
    @POST( "attendance/in")
    Call<JsonObject> callTimeInPI(@Field("user_id") String userid,@Field("in_location") String address, @Field("in_time") String time,@Field("in_location_url") String locationurl,@Field("in_mac_address") String in_mac_address,@Field("client_id") String client_id);


    @FormUrlEncoded
    @POST( "attendance/out")
    Call<JsonObject> callTimeOutAPI(@Field("user_id") String userid,@Field("out_location") String address, @Field("out_time") String time,@Field("out_location_url") String locationurl,@Field("out_mac_address") String out_mac_address,@Field("client_id") String client_id);


    @FormUrlEncoded
    @POST( "user/reset")
    Call<JsonObject> callResetPinAPI(@Field("old_pin") String username, @Field("new_pin") String password, @Field("user_id") String userid,@Field("client_id") String client_id);

    @FormUrlEncoded
    @POST("test")
    Call<JsonObject> callNotificationAPI(@Field("userid") String user_id,@Field("token") String token, @Field("TimeIn") String TimeIn,@Field("client_id") String client_id);

    @FormUrlEncoded
    @POST("admin_notification")
    Call<JsonObject> callAdminNotificationAPI(@Field("user_id") String token, @Field("user_name") String TimeIn,@Field("client_id") String client_id);


    @FormUrlEncoded
    @POST("attendance/list")
    Call<JsonObject> callEmployeListAPI(@Field("user_id") String user_id,@Field("last_id") String last_id,@Field("client_id") String client_id);

    @FormUrlEncoded
    @POST("attendance_filter")
    Call<JsonObject> callEmployeFilterListAPI(@Field("user_id") String user_id,@Field("date") String date,@Field("last_id") String last_id,@Field("client_id") String client_id);

    @FormUrlEncoded

    @POST("attendance_status")
    Call<JsonObject> callEmployeattandenceAPI(@Field("user_id") String user_id,@Field("client_id") String client_id);

    @FormUrlEncoded
    @POST("user/reset_token")
    Call<JsonObject> callLogoutAPI(@Field("user_id") String user_id,@Field("client_id") String client_id);

    @FormUrlEncoded
    @POST("client_detail")
    Call<JsonObject> callCheckClientAPI(@Field("clientname") String clientname);

    @FormUrlEncoded
    @POST("isnotification")
    Call<JsonObject> callNotificationtAPI(@Field("user_id") String user_id,@Field("client_id") String client_id,@Field("isnotification") String isnotification);

    @FormUrlEncoded
    @POST("piechart")
    Call<JsonObject> callAttandenceAPI(@Field("user_id") String user_id,@Field("client_id") String client_id,@Field("month_id") String month_id,@Field("year_id") String year_id);

    @FormUrlEncoded
    @POST("User/list")
    Call<JsonObject> callUserAPI(@Field("client_id") String client_id);

    @Multipart
    @POST("user_detail")
    Call<JsonObject> callUploadInvoiceAPi(@Part("user_id") RequestBody userId, @Part("lattitude") RequestBody lattitude,
                                          @Part("longitude") RequestBody longitude,
                                          @Part("client_id") RequestBody client_id,
                                          @Part MultipartBody.Part file

    );

}
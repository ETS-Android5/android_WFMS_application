package com.wfms.nectar.wfms




import android.app.DatePickerDialog
import android.app.ProgressDialog
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.support.annotation.RequiresApi
import android.support.v7.app.AppCompatActivity
import android.view.WindowManager
import android.widget.ArrayAdapter
import android.widget.Toast
import kotlinx.android.synthetic.main.leave_request_layout.*
import java.text.ParseException
import java.text.SimpleDateFormat
import java.util.*
import android.util.Log
import android.view.View
import android.widget.AdapterView
import android.widget.DatePicker


import com.wfms.nectar.jsonModelResponses.signup.SignUpResponse
import com.wfms.nectar.presenter.presenterImpl.SignUpPresenterImpl
import com.wfms.nectar.presenter.presenterImpl.SignUpPresenterImplOut
import com.wfms.nectar.utils.AppConstants

import com.wfms.nectar.utils.NetworkUtil
import com.wfms.nectar.utils.PrefUtils
import com.wfms.nectar.viewstate.SignUpView
import com.wfms.nectar.viewstate.SignUpViewOut
import kotlinx.android.synthetic.main.leave_layout.*
import java.time.LocalDate
import java.util.concurrent.TimeUnit

class Leave_Request_Activity :AppCompatActivity(), SignUpView, SignUpViewOut, DatePickerDialog.OnDateSetListener {
    override fun onDateSet(view: DatePicker?, year: Int, month: Int, dayOfMonth: Int) {
        ed_fdate.setText("" + year + "-" + (year+1) + "-" + dayOfMonth)
    }

    override fun onSignUpSuccessOut(signUpResponse: SignUpResponse?) {
        dialog.dismiss()
        Toast.makeText(this,"Leaves successfully applied",Toast.LENGTH_SHORT).show()
        intent = Intent(applicationContext, Leave_Activity::class.java)
        startActivity(intent)
    }

    override fun onSignUpFailureOut(msg: String?) {
        dialog.dismiss()
        Toast.makeText(this,"Please try again",Toast.LENGTH_SHORT).show()
    }

    val leave_types = arrayOf("casual", "SickLeave", "Compoff","LWP")
    val leave_for = arrayOf("Full day", "Half day")
    val DATE_FORMAT = "dd-MM-yyyy";
    var leavetype=""
    var leavefor=""
    var availableleaves=""
    val arrayList = ArrayList<LocalDate>()

    internal lateinit var dialog: ProgressDialog
    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN)
        setContentView(R.layout.leave_request_layout)
        //set array for leavetype

        val arrayAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, leave_types)
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        ed_leavetype.adapter = arrayAdapter

        //set array for leavefor
        val arrayAdapter1 = ArrayAdapter(this, android.R.layout.simple_spinner_item, leave_for)
        arrayAdapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        ed_leavefor.adapter = arrayAdapter1

        ed_fdate.setOnClickListener {
          //  setfromDate()
            setfromDate1()
        }

        ed_edate.setOnClickListener {
           // setendDate()
        }
        back_layout.setOnClickListener { view ->
            finish()
        }
        ed_leavetype.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {
                leavetype=leave_types[position]
                Log.d("leavetype",leavetype)
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // Code to perform some action when nothing is selected
            }
        }

        ed_leavefor.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {
                leavefor=leave_for[position]
                Log.d("leavefor",leavefor)
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // Code to perform some action when nothing is selected
            }
        }

        getavailableleaves();

        apply_button.setOnClickListener {

            if (ed_fdate.text.toString().length==0)
            {
                Toast.makeText(this,"Please enter date",Toast.LENGTH_SHORT).show()
            }
            else if (ed_edate.text.toString().length==0)
            {
                Toast.makeText(this,"Please enter date",Toast.LENGTH_SHORT).show()
            }
            else if (reason.text.toString().length==0)
            {
                Toast.makeText(this,"Please enter reason",Toast.LENGTH_SHORT).show()
            }

            else
            {
                applyleave()
            }

        }
    }

    private fun applyleave() {
        if (NetworkUtil.isOnline(getApplicationContext())) {
            dialog = ProgressDialog(this, R.style.AppCompatAlertDialogStyle)
            dialog.setMessage(resources.getString(R.string.loading))
            dialog.show()
            Log.d("leavefor111",leavefor)
            initapplyleavesAPIResources(PrefUtils.getKey(this,AppConstants.Username),availableleaves,leavetype,reason.text.toString(),ed_fdate.text.toString(),ed_edate.text.toString(),leavefor,"2","2",days.text.toString())
          // initapplyleavesAPIResources("rekhalokhande504@gmail.com",availableleaves,leavetype,reason.text.toString(),ed_fdate.text.toString(),ed_edate.text.toString(),leavefor,"2","2",days.text.toString())

        }
        else
        {
            Toast.makeText(this,"Please check internet connection",Toast.LENGTH_SHORT).show()
        }
    }
    private fun getavailableleaves() {
        if (NetworkUtil.isOnline(getApplicationContext())) {
            dialog = ProgressDialog(this, R.style.AppCompatAlertDialogStyle)
            dialog.setMessage(resources.getString(R.string.loading))
            dialog.show()
         //  initavailableleavesAPIResources("rekhalokhande504@gmail.com")
           initavailableleavesAPIResources(PrefUtils.getKey(this,AppConstants.Username))
        }
        else
        {
            Toast.makeText(this,"Please check internet connection",Toast.LENGTH_SHORT).show()
        }
    }
    private fun initavailableleavesAPIResources(name: String) {
        val loginPresenter = SignUpPresenterImpl(this)
        loginPresenter.callApi(AppConstants.Available_Leaves, name)
    }
    private fun initapplyleavesAPIResources(email: String, availableleaves: String, leaveTypes: String, reason: String, startdate: String, enddate: String, leaveFor: String, day: String, reporintmanager: String, totalcount: String) {
        val signupPresenter = SignUpPresenterImplOut(this)

        signupPresenter.callApi(AppConstants.Applyleaves, email.trim(),availableleaves,leaveTypes,reason.trim(),startdate,enddate,leaveFor.trim(),day,reporintmanager,totalcount)
    }
   /* private fun setfromDate() {

        disabledates()
        val calendar= Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)
        val datePickerDialog = DatePickerDialog(this, DatePickerDialog.OnDateSetListener
        { view, year, monthOfYear, dayOfMonth ->

            ed_fdate.setText("" + year + "-" + (monthOfYear+1) + "-" + dayOfMonth)
        }, year, month, day)

       datePickerDialog.getDatePicker().setMinDate(calendar.getTimeInMillis());
      //  datePickerDialog.getDatePicker.
        datePickerDialog.show()
    }
    private fun setfromDate1() {
        val now = Calendar.getInstance()
        DatePickerDialog(
                this,
                { view1, year, month, dayOfMonth -> Log.d("Orignal", "Got clicked") },
                now.get(Calendar.YEAR),
                now.get(Calendar.MONTH),
                now.get(Calendar.DAY_OF_MONTH)
        ).show()
    }*/
   private fun setfromDate1() {
       val now = Calendar.getInstance()
       DatePickerDialog(
               this,
               { view1, year, month, dayOfMonth -> Log.d("Orignal", "Got clicked") },
               now.get(Calendar.YEAR),
               now.get(Calendar.MONTH),
               now.get(Calendar.DAY_OF_MONTH)
       ).show()
   }
    private fun disabledates() {
        for (i in PendingLeaves_Fragment.arrayList1.indices) {
            println("datessssssssssss"+PendingLeaves_Fragment.arrayList1.get(i).from_date)
            println("datesssssssssss1111s"+PendingLeaves_Fragment.arrayList1.get(i).to_date)
            println("name"+PendingLeaves_Fragment.arrayList1.get(i).leavetype_name)
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    /*private fun setendDate() {
        val calendar= Calendar.getInstance()
        val year = calendar.get(Calendar.YEAR)
        val month = calendar.get(Calendar.MONTH)
        val day = calendar.get(Calendar.DAY_OF_MONTH)
        val datePickerDialog = DatePickerDialog(this, DatePickerDialog.OnDateSetListener
        { view, year, monthOfYear, dayOfMonth ->

            val d2 ="" +  year + "-" + (monthOfYear+1) + "-" + dayOfMonth;

            val dfDate = SimpleDateFormat("yyyy-MM-dd")
            var b = false
            try {
                if (dfDate.parse(d2).before(dfDate.parse(ed_fdate.text.toString()))) {
                    b = true//If start date is before end date
                    Toast.makeText(this,"Please select correct date",Toast.LENGTH_SHORT).show()
                    ed_edate.setText(null)
                } else if (dfDate.parse(d2) == dfDate.parse(ed_fdate.text.toString())) {
                    b = true//If two dates are equal
                    ed_edate.setText(d2)
                } else {
                    b = false //If start date is after the end date
                    ed_edate.setText(d2)
                }
                val input_date = ed_fdate.text.toString()
               //add dates in array

                val df = SimpleDateFormat("yyyy-MM-dd")
                val date1 = df.parse(input_date)
                val date2 = df.parse(d2)
                GenerateDates. getDaysBetweenDates(date1,date2)
                val cal1 = Calendar.getInstance()
                val cal2 = Calendar.getInstance()
                cal1.time = date1
                cal2.time = date2

                var numberOfDays = 0
                while (cal1.before(cal2)) {
                    if (Calendar.SATURDAY !== cal1.get(Calendar.DAY_OF_WEEK) && Calendar.SUNDAY !== cal1.get(Calendar.DAY_OF_WEEK)) {
                     //   println(numberOfDays)
                        numberOfDays++
                      //  println(numberOfDays)
                    }
                   *//* else if  (Calendar.SATURDAY !== cal1.get(Calendar.DAY_OF_WEEK))
                            {
                                numberOfDays++
                            }
                    else if  (Calendar.SUNDAY !== cal1.get(Calendar.DAY_OF_WEEK))
                    {
                        numberOfDays++
                    }*//*
                    cal1.add(Calendar.DATE, 1)

                }
                println(numberOfDays)
                var totaldays=numberOfDays+1



               days.setText(""+totaldays)
            } catch (e: ParseException) {
                // TODO Auto-generated catch block
                e.printStackTrace()
            }
        }, year, month, day)
        datePickerDialog.getDatePicker().setMinDate(calendar.getTimeInMillis());
        datePickerDialog.show()
    }*/
    fun getDaysBetweenDates(start: String, end: String): Long {

        val dateFormat = SimpleDateFormat(DATE_FORMAT, Locale.ENGLISH)
        val startDate: Date
        val endDate: Date
        var numberOfDays: Long = 0
        try {
            startDate = dateFormat.parse(start)
            endDate = dateFormat.parse(end)
            numberOfDays = getUnitBetweenDates(startDate, endDate, TimeUnit.DAYS)
            numberOfDays=numberOfDays+1
            days.text=numberOfDays.toString()
            Log.d("numberOfDays", numberOfDays.toString())

        } catch (e: ParseException) {
            e.printStackTrace()
        }
        return numberOfDays
    }
    private fun getUnitBetweenDates(startDate: Date, endDate: Date, unit: TimeUnit): Long {
        val timeDiff = endDate.time - startDate.time
        return unit.convert(timeDiff, TimeUnit.MILLISECONDS)
    }

    override fun onSignUpSuccess(signUpResponse: SignUpResponse?) {
        dialog.dismiss()
        if (signUpResponse != null) {
            available_leaves.text=signUpResponse.leave
            availableleaves=signUpResponse.leave
        }
    }

    override fun onSignUpFailure(msg: String?) {

    }


}




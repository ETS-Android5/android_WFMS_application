package com.wfms.nectar.wfms;

import android.app.Activity;
import android.os.Bundle;
import java.util.ArrayList;

import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import com.github.mikephil.charting.charts.PieChart;

import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;

import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.utils.ColorTemplate;;

import java.util.ArrayList;

public class Leave_Summary_Activity extends AppCompatActivity {
    PieChart pieChart ;
    ArrayList<Entry> entries ;
    ArrayList<String> PieEntryLabels ;
    PieDataSet pieDataSet ;
    PieData pieData ;
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.leave_summary_layout);
        pieChart = (PieChart) findViewById(R.id.pieChart);

        entries = new ArrayList<>();

        PieEntryLabels = new ArrayList<String>();

        AddValuesToPIEENTRY();

        AddValuesToPieEntryLabels();

        pieDataSet = new PieDataSet(entries, "");

        pieData = new PieData(PieEntryLabels,pieDataSet);

       // PieData piedata = new PieData(PieEntryLabels,pieDataSet);
        pieDataSet.setColors(ColorTemplate.COLORFUL_COLORS);

        pieChart.setData(pieData);

        pieChart.animateY(3000);

    }
    public void AddValuesToPIEENTRY(){
        entries.add(new BarEntry(2f, 0));
        entries.add(new BarEntry(4f, 1));
        entries.add(new BarEntry(6f, 2));
        entries.add(new BarEntry(8f, 3));
    }

    public void AddValuesToPieEntryLabels(){
        PieEntryLabels.add("Total Balance");
        PieEntryLabels.add("Pending Leaves");
        PieEntryLabels.add("Approve Leaves");
        PieEntryLabels.add("Rejected Leaves");

    }
}

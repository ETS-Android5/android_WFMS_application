package com.wfms.nectar.interactor.interactorImpl;

import android.util.Log;

import com.google.gson.JsonObject;
import com.wfms.nectar.interactor.ApiInteractor;
import com.wfms.nectar.interactor.Interactor;
import com.wfms.nectar.retrofit.CallbackWithRetry;
import com.wfms.nectar.utils.AppConstants;
import com.wfms.nectar.wfms.WfmslApplication;

import retrofit2.Call;
import retrofit2.Response;


public class SignUpInteractorImpl implements Interactor {
    private static final String TAG = SignUpInteractorImpl.class.getSimpleName();

    @Override
    public void callApi(ApiInteractor apiInteractor, Object... args) {
        String title = (String) args[0];

        if (title.equalsIgnoreCase(AppConstants.LOGIN)) {
            callLoginAPI((String) args[1], (String) args[2], (String) args[3], (String) args[4], apiInteractor);

        } else if (title.equalsIgnoreCase(AppConstants.TimeIN)) {
            callTimeINAPI((String) args[1], (String) args[2], (String) args[3], (String) args[4], (String) args[5], (String) args[6], apiInteractor);

        } else if (title.equalsIgnoreCase(AppConstants.TimeOut)) {
            callTimeOutAPI((String) args[1], (String) args[2], (String) args[3], (String) args[4], (String) args[5], (String) args[6], apiInteractor);

        } else if (title.equalsIgnoreCase(AppConstants.Reset_Pin)) {
            callResetPinAPI((String) args[1], (String) args[2], (String) args[3], (String) args[4], apiInteractor);

        } else if (title.equalsIgnoreCase(AppConstants.Notification)) {
            callNotificationAPI((String) args[1], (String) args[2], (String) args[3], (String) args[4], apiInteractor);


        } else if (title.equalsIgnoreCase(AppConstants.AdminNotification)) {
            callAdminNotificationAPI((String) args[1], (String) args[2], (String) args[3], apiInteractor);

        } else if (title.equalsIgnoreCase(AppConstants.updated)) {
            callattandenceupdateAPI((String) args[1], (String) args[2], apiInteractor);


        } else if (title.equalsIgnoreCase(AppConstants.Logout)) {
            calllogoutAPI((String) args[1], (String) args[2], apiInteractor);

        } else if (title.equalsIgnoreCase(AppConstants.Client)) {
            callCheckClientAPI((String) args[1], apiInteractor);

        } else if (title.equalsIgnoreCase(AppConstants.NotificationEnable)) {
            callNotificationEnableAPI((String) args[1],(String) args[2],(String) args[3], apiInteractor);

        }
        else if (title.equalsIgnoreCase(AppConstants.Attandence)) {
            callAttandenceAPI((String) args[1],(String) args[2],(String) args[3],(String) args[4], apiInteractor);

        }
    }

    private void callNotificationEnableAPI(String userid, String clientid, String isnotification, ApiInteractor mListener) {

    Call<JsonObject> call = WfmslApplication.mRetroClient.callNotificationtAPI(userid,clientid,isnotification);
    requestCall(call,mListener);
    }

    public void callTimeINAPI(String userid, String address, String time, String locationurl,String deviceID, String clientid,final ApiInteractor mListener) {

      Call<JsonObject> call = WfmslApplication.mRetroClient.callTimeInPI(userid,address,time,locationurl,deviceID,clientid);
      requestCall(call,mListener);
  }
    public void callTimeOutAPI(String userid, String address, String time,String locationurl, String deviceID, String clientid,final ApiInteractor mListener) {

        Call<JsonObject> call = WfmslApplication.mRetroClient.callTimeOutAPI(userid,address,time,locationurl,deviceID,clientid);
        requestCall(call,mListener);
    }
    public void callResetPinAPI(String oldpassword, String password, String userid,String clientid,final ApiInteractor mListener) {

        Call<JsonObject> call = WfmslApplication.mRetroClient.callResetPinAPI(oldpassword,password,userid,clientid);
        requestCall(call,mListener);
    }
    public void callLoginAPI( String name, String password,String tokenid,String clientname, final ApiInteractor mListener) {

        Call<JsonObject> call = WfmslApplication.mRetroClient.callLoginAPI(name,password,tokenid,clientname);
        requestCall(call,mListener);
    }
    public void callNotificationAPI(String userid,String tokenid, String currenttime,String clientid,final ApiInteractor mListener) {

        Call<JsonObject> call = WfmslApplication.mRetroClient.callNotificationAPI(userid,tokenid,currenttime,clientid);
        requestCall(call,mListener);
    }
    public void callAdminNotificationAPI(String userid, String username,String clientid,final ApiInteractor mListener) {

        Call<JsonObject> call = WfmslApplication.mRetroClient.callAdminNotificationAPI(userid,username,clientid);
        requestCall(call,mListener);
    }
    public void callattandenceupdateAPI(String userid,String clientid,final ApiInteractor mListener) {

        Call<JsonObject> call = WfmslApplication.mRetroClient.callEmployeattandenceAPI(userid,clientid);
        requestCall(call,mListener);
    }
    public void calllogoutAPI(String userid,String clienttid,final ApiInteractor mListener) {

        Call<JsonObject> call = WfmslApplication.mRetroClient.callLogoutAPI(userid,clienttid);
        requestCall(call,mListener);
    }
    public void callCheckClientAPI( String clientname, final ApiInteractor mListener) {

        Call<JsonObject> call = WfmslApplication.mRetroClient.callCheckClientAPI(clientname);
        requestCall(call,mListener);
    }
    private void callAttandenceAPI(String userid, String clientid, String monthid,String year, ApiInteractor mListener) {

        Call<JsonObject> call = WfmslApplication.mRetroClient.callAttandenceAPI(userid,clientid,monthid,year);
        requestCall(call,mListener);
    }
  private void requestCall(Call<JsonObject> call, final ApiInteractor mListener){
      Log.d(TAG, call.request().toString());
      call.enqueue(new CallbackWithRetry<JsonObject>(call) {
          @Override
          public void onResponse(Call<JsonObject> call, Response<JsonObject> response) {
             // Log.d(TAG, "onResponse: " + response);
              if (response.isSuccessful()) {
                  Log.d(TAG, "onResponse: " + response.body());
                  mListener.onSuccess(response.body());
              } else {
                  if (response.errorBody() != null) {
                      mListener.onFailure("");
                  } else {
                      onFailure(call, new Throwable());
                  }
              }
          }

          @Override
          public void onFailure(Call<JsonObject> call, Throwable t) {
              if (!onFailureResponse(call, t)) {
                  mListener.onFailure("");
              }
          }
      });
  }
}


